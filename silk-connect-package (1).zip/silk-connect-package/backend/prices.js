// Live silkworm-cocoon market prices for Silk-Connect.
//
// Source: Agmarknet daily mandi prices, published by the Government of India on
// data.gov.in ("Current Daily Price of Various Commodities from Various Markets
// (Mandi)"). It covers every state that reports cocoon trades and is refreshed
// daily. A free API key from data.gov.in (My Account) is required.
//
// Note: the Central Silk Board itself only publishes cocoon / raw-silk prices as
// monthly PDF bulletins (mostly Ramanagara, Karnataka), not as a live feed. Those
// monthly figures can be added in csb-monthly.json and are shown next to the live
// rates as a reference.

const fs = require("fs");
const path = require("path");

const DEFAULT_RESOURCE = "9ef84268-d588-465a-a308-a864a43d0070";
const DEFAULT_BASE = "https://api.data.gov.in/resource/" + DEFAULT_RESOURCE;
const MAX_AGE_DAYS = 30;      // ignore markets whose latest reported price is older than this
const CACHE_TTL_MS = 3 * 60 * 60 * 1000;

// "05/10/2026" -> "2026-10-05"
function parseArrivalDate(d) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(String(d || "").trim());
  return m ? `${m[3]}-${m[2]}-${m[1]}` : null;
}
function positive(v) {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : null;
}
const perKg = (quintal) => Math.round((quintal / 100) * 100) / 100; // Rs/quintal -> Rs/kg

// Remembers the previous reading for each market so we can show "vs yesterday".
// (In memory only: after a restart the trend appears again from the second day.)
const history = new Map();
function withTrend(key, date, avg) {
  const h = history.get(key);
  if (!h) { history.set(key, { date, avg, prevAvg: null }); return null; }
  if (date > h.date) { history.set(key, { date, avg, prevAvg: h.avg }); return h.avg; }
  h.avg = avg;               // same day: keep the earlier "previous" value
  return h.prevAvg;
}

function daysBetween(isoA, isoB) {
  return Math.round((Date.parse(isoB + "T00:00:00Z") - Date.parse(isoA + "T00:00:00Z")) / 86400000);
}

// records: raw rows from data.gov.in. Returns { "Karnataka": [ {name, variety, max, avg, min, date, yesterdayAvg} ] }
function normalize(records, todayISO) {
  const latest = new Map(); // state|market|variety -> best record
  for (const r of records) {
    if (!/cocoon/i.test(r.commodity || "")) continue;
    const date = parseArrivalDate(r.arrival_date);
    const avg = positive(r.modal_price), max = positive(r.max_price), min = positive(r.min_price);
    if (!date || !avg || !r.state || !r.market) continue;
    if (todayISO && daysBetween(date, todayISO) > MAX_AGE_DAYS) continue;
    const rawVariety = (r.variety && r.variety !== "Other" ? r.variety : r.commodity);
    const variety = String(rawVariety).replace(/^silk\s*cocoon\s*/i, "").replace(/_/g, " ").replace(/\s+/g, " ").trim() || "Cocoon";
    const key = `${r.state}|${r.market}|${variety}`;
    const prev = latest.get(key);
    if (!prev || date > prev.date) {
      latest.set(key, { key, state: r.state.trim(), market: r.market.trim(), variety, date,
        avg: perKg(avg), max: perKg(max || avg), min: perKg(min || avg) });
    }
  }
  // names must be unique inside a state
  const perMarket = new Map();
  for (const x of latest.values()) {
    const k = `${x.state}|${x.market}`;
    perMarket.set(k, (perMarket.get(k) || 0) + 1);
  }
  const out = {};
  for (const x of [...latest.values()].sort((a, b) => a.market.localeCompare(b.market))) {
    const multi = perMarket.get(`${x.state}|${x.market}`) > 1;
    (out[x.state] = out[x.state] || []).push({
      name: multi ? `${x.market} (${x.variety})` : x.market,
      variety: x.variety, max: x.max, avg: x.avg, min: x.min, date: x.date,
      yesterdayAvg: withTrend(x.key, x.date, x.avg)
    });
  }
  return out;
}

async function fetchAllRecords({ fetchFn, apiKey, baseUrl = DEFAULT_BASE, pageSize = 1000, maxPages = 60 }) {
  const all = [];
  for (let page = 0; page < maxPages; page++) {
    const url = `${baseUrl}?api-key=${encodeURIComponent(apiKey)}&format=json&limit=${pageSize}&offset=${page * pageSize}`;
    const res = await fetchFn(url);
    if (!res.ok) throw new Error(`data.gov.in responded ${res.status}`);
    const body = await res.json();
    const rows = Array.isArray(body.records) ? body.records : [];
    all.push(...rows);
    if (rows.length < pageSize) break;
    if (body.total && all.length >= Number(body.total)) break;
  }
  return all;
}

function readCsbMonthly(file = path.join(__dirname, "csb-monthly.json")) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch (e) { return []; }
}

function createPriceService({ fetchFn, apiKey, baseUrl, now = () => new Date(), csbFile } = {}) {
  let cache = null;      // { at, data }
  let inflight = null;

  async function refresh() {
    if (!apiKey) { const e = new Error("DATA_GOV_API_KEY is not set"); e.code = "NO_KEY"; throw e; }
    const records = await fetchAllRecords({ fetchFn, apiKey, baseUrl });
    const today = now().toISOString().slice(0, 10);
    const states = normalize(records, today);
    cache = {
      at: now().getTime(),
      data: {
        source: "Agmarknet daily mandi prices via data.gov.in (Govt. of India)",
        fetchedAt: now().toISOString(),
        marketCount: Object.values(states).reduce((n, a) => n + a.length, 0),
        states,
        csbMonthly: readCsbMonthly(csbFile)
      }
    };
    return cache.data;
  }

  async function getPrices() {
    if (cache && now().getTime() - cache.at < CACHE_TTL_MS) return cache.data;
    if (!inflight) inflight = refresh().finally(() => { inflight = null; });
    try {
      return await inflight;
    } catch (err) {
      if (cache) return { ...cache.data, stale: true };   // serve the last good copy
      throw err;
    }
  }
  return { getPrices };
}

module.exports = { createPriceService, normalize, parseArrivalDate, fetchAllRecords, DEFAULT_BASE };
